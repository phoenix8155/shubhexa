<?php defined('BASEPATH') OR exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
|  Google API Configuration
| -------------------------------------------------------------------
|  client_id         string   Your Google API Client ID.
|  client_secret     string   Your Google API Client secret.
|  redirect_uri      string   URL to redirect back to after login.
|  application_name  string   Your Google application name.
|  api_key           string   Developer key.
|  scopes            string   Specify scopes
 */
$config['google']['client_id'] = '795972039102-h4itc76d9n5hns1nkrii7mftv7vcnm90.apps.googleusercontent.com';
$config['google']['client_secret'] = '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';
$config['google']['redirect_uri'] = 'https://pnxschool.com/shubhexa/index.php/ulogin/google_login';
$config['google']['application_name'] = 'best for login';
$config['google']['api_key'] = '';
$config['google']['scopes'] = array('email' => '', 'profile' => '');
